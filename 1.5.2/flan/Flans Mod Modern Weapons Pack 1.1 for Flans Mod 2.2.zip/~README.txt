Modern Weapons Pack 1.1 for Flan's Mod 2.2

Place the folder contained in this zip in "/.minecraft/Flan/"
You may need to create the "Flan" folder if it does not exist