To install:
	Simply drag the contents of this folder into your minecraft.jar
	~ OR ~
	Use the entire packaged folder with the loader of your choice
	(Make sure you delete META-INF and have Forge installed!)

The version is v.4.0.0. This mod will only work with Minecraft [1.6.x].

New recipes:
	Trap-door (with wood walls enabled) ~ ['x' = planks, 'o' = stick]

		-  -  -
		x  x  x
		x  o  x

	Fences (with new fences enabled) ~ ['x' = planks, 'o' = stick]
	
		-  -  -
		x  o  x
		x  o  x

	Wood walls ~ ['x' = planks]
	
		-  -  -
		x  x  x
		x  x  x
	
Known issues:
	Posts don't stack in the way that I want them to.
	Lighting will pass through stacked walls and is not configured correctly for walls in general.

Changelog
	v.4.0.0 (9/8)
		- updated for Minecraft 1.6.2
		- cleaned up code and rewrote rendering in preparation for open-source release
		- reworked rendering of wooden walls and added option to use custom texture for them
		- reworked connectivity between fences and walls: fences now extend to connect
		- added new fences for the different wood types
		- added quartz wall
		- removed "smart-connect" and "pseudo-arch" features
		- removed unnecessary and buggy torch code
		- changed default trapdoor recipe when wooden walls are enabled
		- fixed being able to attack and shoot projectiles through solid walls
		- fixed gaps sometimes forming in wall corners
		- cleaned up config
	v.3.1.3 (5/15)
		- fixed bug with walls not dropping the correct block in Survival
		- added config option to adjust wall height (default at 1.0 blocks)
	v.3.1.2 (5/5)
		- gave trapdoors their vanilla recipe back and changed the recipe for wooden walls to use slabs
			added a config option to reverse this change
	v.3.1.1 (5/3)
		- updated for Minecraft 1.5.x
	v.3.1 (3/15)
		- fixed bug involving fence collision
		- fixed bug involving annoying torch placement
		- fixed flickering in interactions between walls and fences
		- fixed gaps forming between walls and panes
	v.3.0 (3/10)
		- updated for Minecraft 1.5
		- vanilla walls are (safely) overwritten by default
			removed separate blockID for core wall blocks
			mod can be installed and removed without affecting vanilla wall blocks
		- fixed a number of visual issues with walls 
		    (bottom row of stacked walls, stacked walls connecting to fences, connecting to gates, 
		    (stretching when) connecting to panes, and connections in corners)
		- fixed being unable to palce torches on additional wall types
		- removed "pseudo-arch" wall behavior
			fixes issue with stretched textures on stacked walls (and looks a bit cleaner, IMO)
			can be reverted in config
		- (possibly) fixed compatibility issue with CTM
		- added optional wooden walls
		- added option to incorporate nether bricks into the nether fence and wall recipes
		- cleaned up and fixed config options
	v.2.4 (12/20)
		- updated for Minecraft 1.4.6
		- changed default blockIDs to prevent conflict [Forge]
	v.2.3.1 (12/13)
		- fixed torch placement bug
	v.2.3 (12/11)
		- fixed config option for wall height
		- fixed faces of walls not rendering in certain situations
		- fixed issue with connectivity between walls and fences/fence gates
		- added optional obsidian walls (disabled by default)
		- added compatibility support for fences and stairs added by other mods
		- removed now unnecessary compatibility file (between Better Blocks & Items)
	v.2.2.1 (11/22)
		- added compatibility fix for Better Blocks & Items
	v.2.2 (11/20)
		- updated to Minecraft 1.4.5
		- fixed SMP support (for real this time!) [Forge]
	v.2.1 (11/12)
		- fixed mod being packaged incorrectly [ModLoader]
		- fixed torch placement not working when vanilla fences overwritten
		- fixed and cleaned-up config for both versions 
		- added SMP support (?) [Forge]
	v.2.0.1 (11/4)
		- fixed mismatched wall names
		- fixed minor issues with config
	v.2.0 (11/3)
		- updated to Minecraft 1.4.2
			NOTE: to update older builds that used Fancy Fences, you can either:
			1)	change blockID in config to ID that was previously used
			2)	before updating, change Fancy Fence blockID in old world to 139 and use 
				   a map editor to replace all instances of the walls in your world
		- integrated mod with newly added vanilla walls
			- by default, modded walls override vanilla walls 
				walls automatically converted when mod is installed
					revert automatically when mod is uninstalled or ID changes
				vanilla walls are overrided safely w/o corrupting builds that use them
					metadata is matched for complete compatibility
				override can be disabled in config
			- inv render adjusted to incorporate vanilla changes
			- recipe adjusted to match vanilla changes (6 walls created instead of 4)
			- gate connectivity adjusted to incorporate vanilla changes
				only if vanilla walls overriden
				otherwise, gates will interact in the same way as before
		- made progress on a (very much needed) general clean-up of the code
		- walls with torches or fences placed above them now form posts
			- same support added for mob heads and signs
		- adjusted names for sandstone and stone brick variants in inventory
		- tweaked fence connectivity
		- adjusted wall height and thickness
			- height changes help to alleviate some "stretching" issues with stacked walls
		- integrated the Better Fences component of Better Blocks & Items mod
			mainly done for consistency and compatibility reasons
			all changes made to fences are modular and can be enabled or disabled separately of one-another
				fences  - enables base Better Fences features and opens the options below
				nosoil  - prevents fences from connecting to soil blocks
				blend   - allows wooden and nether fences to connect
				corners - causes fences to automatically connect in corners
				collision - adjusts height of hitbox to match normal blocks 
				   (mobs that don't try to jump over fences will be contained)
				
	v.1.7.1 (9/11)
		- restructured code to remove need for compatibility patches
		- moved textures to /vanillawithsprinkles/textures/*
		- improved compatibility with mod-loading programs
	v.1.7 (9/8)
		- updated for Forge v.4.0
		- removed reliance on base class edits (BlockPane)
		- fixed issues w/ torch placement and sandstone wall textures
		- reduced wall thickness (w/ config option to revert change)
		- changed stone wall texture (w/ config option to revert change)
	v.1.6 (8/18)
		- updated for Minecraft 1.3.2
		- removed reliance on base class edits (BlockTorch)
		- removed reliance on base class edits (BlockFence)
	v.1.5 (8/16)
		- fixed(?) torches not connecting to posts in certain situations
		- added Forge support
	V.1.4 (8/9)
		- added SMP (ModLoaderMP) support
	v.1.3 (8/4)
		- updated for Minecraft 1.3.1
		- slightly improved connectivity with panes
		- added optional connectivity with torches
		- walls now connect to (properly positioned) stairs and slabs
		- added compatibility patch for my 'Better Blocks & Items' mod
	v.1.2 (7/26)
		- added connectivity with normal blocks (2+ aligned walls will connect to perpendicular blocks, walls will fill gap between normal blocks above them)
		- added missing sandstone wall variant
		- fixed nether brick wall crafting recipe 
			nether brick fences now crafted with 2x2 nether bricks
			old recipes can be re-enabled in config
		- added config option to adjust walls' collision height
		- improved connectivity with gates
		- added optional connectivity with panes
		- improved connectivity with fences, and option to improve further
	v.1.1 (6/27)
		- added config support:
			fancyfencesID - changes blockID used
	v.1.0 (6/23)
		- released

Please leave feedback/any other questions you may have on the official topic:
	http://www.minecraftforum.net/topic/1298016-132
You can also contact me and follow updates through my YouTube channel:
	http://www.youtube.com/koopinator

Otherwise, I hope you enjoy! :D

- Ian